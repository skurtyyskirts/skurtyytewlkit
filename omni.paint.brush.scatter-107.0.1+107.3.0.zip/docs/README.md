# Scatter Brush Extension [omni.paint.brush.scatter]
Scatter brush used in paint tool