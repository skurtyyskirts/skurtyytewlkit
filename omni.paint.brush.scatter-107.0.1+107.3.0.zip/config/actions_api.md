# Actions in omni.paint.brush.scatter

| ID        | Display Name | Description |
|:----------|:----------|:----------|
| add_asset | Add Asset | Add Asset |
